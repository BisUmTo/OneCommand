'RedCraft 2' [18w03b] by BisUmTo
http://youtube.com/BisUmTo

Credit BisUmTo if use this datapack.
Don't re-upload this command: provide my video link instead!!

This datapack consists of 3 sub-functions:
- Multiplayer Bed
- Gamemode Changer
- Grave

To install this datapack:
- Put this .zip file in the datapacks folder of your world.
- Run the command /reload